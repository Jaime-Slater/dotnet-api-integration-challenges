﻿using System.Net.Http.Json;
using Models;

Console.WriteLine("GitHub Repo Health Checker!");

while (true)
{
    Console.WriteLine("Enter a Github repo owner or type Exit to close the app.");
    string? owner = Console.ReadLine();
    if (string.IsNullOrEmpty(owner))
    {
        Console.WriteLine("No owner entered.");
        continue;
    }

    if (owner.ToLower() == "exit")
    {
        Console.WriteLine("Exiting app");
        return;
    }

    bool hasEnteredRepoName = false;
    string? repo = null;

    while (!hasEnteredRepoName)
    {
        Console.WriteLine("Enter a Github repo name or type Exit to close the app.");
        repo = Console.ReadLine();
        if (string.IsNullOrEmpty(repo))
        {
            Console.WriteLine("No repo entered.");
            continue;
        }

        hasEnteredRepoName = true;
    }

    if (repo?.ToLower() == "exit")
    {
        Console.WriteLine("Exiting app");
        return;
    }


    Console.WriteLine($"Looking on GitHub for the repository: {repo} created by: {owner}");

    var httpClient = new HttpClient
    {
        BaseAddress = new Uri("https://api.github.com/"),
    };

    //Github requires User Agent header.
    httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("GitHubRepoHealthChecker/1.0");

    try
    {
        using HttpResponseMessage response = await httpClient.GetAsync($"repos/{owner}/{repo}");

        response.EnsureSuccessStatusCode();

        if (!response.IsSuccessStatusCode)
        {
            Console.WriteLine($"Failed to get API response for: {repo} created by: {owner}. Error: {response.RequestMessage}");
            return;
        }

        var gitHubRepo = await response.Content.ReadFromJsonAsync<GitHubRepositoryResponse>();

        if (gitHubRepo is null)
        {
            Console.WriteLine($"Failed format data for: {repo} created by: {owner}. Error: GitHubRepositoryResponse is null");
            return;
        }

        var healthRating = GetHealthRating(gitHubRepo);

        Console.WriteLine($"Repository: {gitHubRepo.FullName}");
        Console.WriteLine($"Description: {gitHubRepo.Description}");
        Console.WriteLine($"Language: {gitHubRepo.Language}");
        Console.WriteLine($"Stars: {gitHubRepo.StargazersCount:n0}");
        Console.WriteLine($"Forks: {gitHubRepo.ForksCount:n0}");
        Console.WriteLine($"Open Issues: {gitHubRepo.OpenIssuesCount:n0}");
        Console.WriteLine($"Last Updated: {gitHubRepo.UpdatedAt:yyyy-MM-dd}");
        Console.WriteLine($"");
        Console.WriteLine($"Health Rating: {healthRating}");
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }

}

string GetHealthRating(GitHubRepositoryResponse gitHubRepo)
{
    if (gitHubRepo.Archived)
        return "Archived";

    if (gitHubRepo.OpenIssuesCount > 1000)
        return "Busy";

    if (gitHubRepo.UpdatedAt > DateTime.Now.AddDays(-30))
        return "Active";

    if (gitHubRepo.UpdatedAt > DateTime.Now.AddDays(-180))
        return "Maintained";

    return "Stale";
}